from database import db
from models import Booking
from datetime import datetime
import uuid
from app import app  

def seed_data():
    reservations = [
        {
            "user_id": 1,
            "pickup_location": "Location A",
            "dropoff_location": "Location B",
            "departure_date": "2024-10-25",
            "departure_time": "14:30:00",
            "vehicle_brand": "Toyota",
            "vehicle_color": "Red",
            "vehicle_mileage": 50000,
        },
        {
            "user_id": 2,
            "pickup_location": "Location C",
            "dropoff_location": "Location D",
            "departure_date": "2024-11-01",
            "departure_time": "10:00:00",
            "vehicle_brand": "Honda",
            "vehicle_color": "Blue",
            "vehicle_mileage": 30000,
        },
        {
            "user_id": 3,
            "pickup_location": "Location E",
            "dropoff_location": "Location F",
            "departure_date": "2024-11-15",
            "departure_time": "09:45:00",
            "vehicle_brand": "Ford",
            "vehicle_color": "Black",
            "vehicle_mileage": 80000,
        },
    ]

    for res in reservations:
        booking_token = str(uuid.uuid4())
        departure_date = datetime.strptime(res['departure_date'], '%Y-%m-%d').date()
        departure_time = datetime.strptime(res['departure_time'], '%H:%M:%S').time()

        booking = Booking(
            user_id=res['user_id'],
            pickup_location=res['pickup_location'],
            dropoff_location=res['dropoff_location'],
            departure_date=departure_date,
            departure_time=departure_time,
            vehicle_brand=res['vehicle_brand'],
            vehicle_color=res['vehicle_color'],
            vehicle_mileage=res['vehicle_mileage'],
            token=booking_token
        )

        db.session.add(booking)

    db.session.commit()

if __name__ == "__main__":
    with app.app_context():
        seed_data()
        print("Données de réservation fictives ajoutées avec succès !")
