from sqlalchemy import Column, Integer, String, Float, Time, Date, ForeignKey
import uuid
from database import db

class Booking(db.Model):
    __tablename__ = 'bookings'
    
    id = Column(Integer, primary_key=True, autoincrement=True) 
    user_id = Column(String, nullable=False)
    pickup_location = Column(String, nullable=False)
    dropoff_location = Column(String, nullable=False)
    departure_date = Column(Date, nullable=False)
    departure_time = Column(Time, nullable=False)
    token = Column(String, nullable=False, unique=True, default=str(uuid.uuid4()))  
    
    vehicle_brand = Column(String, nullable=True)
    vehicle_color = Column(String, nullable=True)
    vehicle_mileage = Column(Integer, nullable=True)