from flask_sqlalchemy import SQLAlchemy  # Utilisation de SQLAlchemy de Flask
import os
from dotenv import load_dotenv
from sqlalchemy import inspect


load_dotenv()

db = SQLAlchemy()

DATABASE_URL = os.getenv('DB_URL')


def table_exists(table_name, engine):
    inspector = inspect(engine)
    return inspector.has_table(table_name)

def init_db(app):
    with app.app_context():
        db.create_all()
