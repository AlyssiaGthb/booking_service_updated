from flask import Flask, request, jsonify
from flask_migrate import Migrate
from database import db  
from models import Booking
from datetime import datetime
import uuid
import os
from dotenv import load_dotenv
from flask_jwt_extended import JWTManager, jwt_required, get_jwt_identity


load_dotenv()


app = Flask(__name__)


app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DB_URL')  
app.config['JWT_SECRET_KEY'] = os.getenv('SECRET_KEY')  
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  

db.init_app(app)

migrate = Migrate(app, db)

jwt = JWTManager(app)

@app.route('/bookings/create', methods=['POST'])
@jwt_required()
def create_booking():
    try:
        data = request.get_json()
        pickup_location = data.get('pickup_location')
        dropoff_location = data.get('dropoff_location')
        departure_date = data.get('departure_date')
        departure_time = data.get('departure_time')

        vehicle_brand = data.get('vehicle_brand')
        vehicle_color = data.get('vehicle_color')
        vehicle_mileage = data.get('vehicle_mileage')

        if not departure_date or not departure_time:
            return jsonify({"error": "departure_date et departure_time sont requis"}), 400

        departure_date = datetime.strptime(departure_date, '%Y-%m-%d').date()
        departure_time = datetime.strptime(departure_time, '%H:%M:%S').time()

        booking_token = str(uuid.uuid4())

        current_user = get_jwt_identity()

        booking = Booking(
            user_id=current_user['username'],  
            pickup_location=pickup_location,
            dropoff_location=dropoff_location,
            departure_date=departure_date,
            departure_time=departure_time,
            token=booking_token,
            vehicle_brand=vehicle_brand,
            vehicle_color=vehicle_color,
            vehicle_mileage=vehicle_mileage
        )

        db.session.add(booking)
        db.session.commit()

        return jsonify({"message": "Réservation enregistrée avec succès", "booking_token": booking_token}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/bookings/cancel/<string:booking_token>', methods=['DELETE'])
@jwt_required()
def cancel_booking(booking_token):
    try:
        booking = Booking.query.filter_by(token=booking_token).first()

        if not booking:
            return jsonify({"error": "Réservation avec le token fourni introuvable"}), 404

        db.session.delete(booking)
        db.session.commit()

        return jsonify({"message": f"Réservation avec le token {booking_token} a été annulée"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/bookings/filter', methods=['GET'])
@jwt_required()
def filter_bookings():
    try:
        vehicle_brand = request.args.get('vehicle_brand')
        vehicle_color = request.args.get('vehicle_color')
        vehicle_mileage = request.args.get('vehicle_mileage')

        query = Booking.query  

        if vehicle_brand:
            query = query.filter_by(vehicle_brand=vehicle_brand)
        if vehicle_color:
            query = query.filter_by(vehicle_color=vehicle_color)
        if vehicle_mileage:
            query = query.filter(Booking.vehicle_mileage <= int(vehicle_mileage))

        bookings = query.all()

        results = [
            {
                "pickup_location": booking.pickup_location,
                "dropoff_location": booking.dropoff_location,
                "departure_date": booking.departure_date.strftime('%Y-%m-%d'),
                "departure_time": booking.departure_time.strftime('%H:%M:%S'),
                "vehicle_brand": booking.vehicle_brand,
                "vehicle_color": booking.vehicle_color,
                "vehicle_mileage": booking.vehicle_mileage,
                "booking_token": booking.token
            }
            for booking in bookings
        ]

        return jsonify(results), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5002)
